<?php
session_start();

// Admin Only Access
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || !isset($_SESSION['admin_id'])) {
    header("Location: ../index.php");
    exit();
}

include 'php/db_config.php';

// Calculate pending support messages
$pendingSupportCount = 0;
$countResult = $conn->query("SELECT COUNT(*) AS pending FROM support_messages WHERE response IS NULL");
if ($countRow = $countResult->fetch_assoc()) {
    $pendingSupportCount = $countRow['pending'];
}

// Handle operations (CRUD)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    $table = $_POST['table'];

    if ($_POST['action'] == 'add') {
        $columns = implode(",", array_keys($_POST['data']));
        $values = implode(",", array_map(function($value) use ($conn) {
            return "'" . $conn->real_escape_string($value) . "'";
        }, $_POST['data']));
        $sql = "INSERT INTO $table ($columns) VALUES ($values)";
        $conn->query($sql);
    }

    if ($_POST['action'] == 'edit') {
        $id = $_POST['id'];
        $updates = [];
        foreach ($_POST['data'] as $key => $value) {
            $updates[] = "$key = '" . $conn->real_escape_string($value) . "'";
        }
        $updates = implode(",", $updates);
        $primaryKey = getPrimaryKey($table);
        $sql = "UPDATE $table SET $updates WHERE $primaryKey = $id";
        $conn->query($sql);
    }

    if ($_POST['action'] == 'delete') {
        $id = $_POST['id'];
        $primaryKey = getPrimaryKey($table);
        $sql = "DELETE FROM $table WHERE $primaryKey = $id";
        $conn->query($sql);
    }
}

// Handle admin response to support messages
if (isset($_POST['support_reply_id'], $_POST['support_response'])) {
    $supportId = (int)$_POST['support_reply_id'];
    $responseText = $conn->real_escape_string($_POST['support_response']);
    $adminId = (int)$_SESSION['admin_id'];

    $conn->query("UPDATE support_messages SET response = '$responseText', responded_at = NOW(), admin_id = $adminId WHERE id = $supportId");

    // Update pending count
    $countResult = $conn->query("SELECT COUNT(*) AS pending FROM support_messages WHERE response IS NULL");
    if ($countRow = $countResult->fetch_assoc()) {
        $pendingSupportCount = $countRow['pending'];
    }
}

// Get primary key dynamically
function getPrimaryKey($table) {
    global $conn;
    $result = $conn->query("DESCRIBE $table");
    while ($row = $result->fetch_assoc()) {
        if ($row['Key'] == 'PRI') {
            return $row['Field'];
        }
    }
    return null;
}

// Get table names
$tableResult = $conn->query("SHOW TABLES");
$tables = [];
while ($row = $tableResult->fetch_row()) {
    $tables[] = $row[0];
}

$table = isset($_GET['table']) ? $_GET['table'] : $tables[0];
$searchTerm = isset($_GET['search']) ? $_GET['search'] : '';

// Search query
function getColumns($table) {
    global $conn;
    $columns = [];
    $result = $conn->query("DESCRIBE $table");
    while ($row = $result->fetch_assoc()) {
        $columns[] = $row['Field'];
    }
    return $columns;
}

if ($searchTerm) {
    $searchColumns = getColumns($table);
    $likeFields = implode(", ", array_map(fn($col) => "`$col`", $searchColumns));
    $sql = "SELECT * FROM $table WHERE CONCAT_WS(' ', $likeFields) LIKE '%$searchTerm%'";
} else {
    $sql = "SELECT * FROM $table";
}
$tableData = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="css/manage.css">
    <style>
        .logout-btn { text-align: right; padding: 10px 20px; }
        .logout-btn a { background-color: #e74c3c; color: white; padding: 10px 20px; text-decoration: none; font-weight: bold; border-radius: 5px; }
        .logout-btn a:hover { background-color: #c0392b; }
        .search-container { padding: 20px 0; }
        input[type="text"] { padding: 8px; width: 250px; }
        button[type="submit"] { padding: 8px 16px; }
        .notif-badge { background: red; color: white; padding: 2px 6px; border-radius: 10px; font-size: 12px; margin-left: 5px; }
        .filter-buttons { margin-bottom: 20px; }
        .filter-buttons button { padding: 10px 15px; margin-right: 10px; }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>Admin Dashboard</h2>
        <?php foreach ($tables as $t): ?>
            <?php if ($t == 'support_messages'): ?>
                <a href="?table=support_messages" onclick="showSupportNotice()">
                    <?= ucfirst($t) ?>
                    <?php if ($pendingSupportCount > 0): ?>
                        <span id="notifBadge" class="notif-badge"><?= $pendingSupportCount ?></span>
                    <?php endif; ?>
                </a>
            <?php else: ?>
                <a href="?table=<?= $t ?>"><?= ucfirst($t) ?></a>
            <?php endif; ?>
        <?php endforeach; ?>
    </div>

    <div class="main-content">
        <div class="logout-btn">
            <a href="php/logout.php">Logout</a>
        </div>

        <h1>Manage <?= ucfirst($table) ?></h1>

        <div class="search-container">
            <form method="GET">
                <input type="text" name="search" placeholder="Search..." value="<?= htmlspecialchars($searchTerm) ?>">
                <input type="hidden" name="table" value="<?= htmlspecialchars($table) ?>">
                <button type="submit">Search</button>
            </form>
        </div>

        <table border="1" cellpadding="10">
            <thead>
                <tr>
                    <?php foreach (getColumns($table) as $col): ?>
                        <th><?= ucfirst($col) ?></th>
                    <?php endforeach; ?>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $tableData->fetch_assoc()): ?>
                    <tr>
                        <?php foreach ($row as $value): ?>
                            <td><?= htmlspecialchars($value) ?></td>
                        <?php endforeach; ?>
                        <td>
                            <?php $primaryKey = getPrimaryKey($table); ?>
                            <button onclick="openEditForm('<?= $table ?>', <?= $row[$primaryKey] ?>)">Edit</button>
                            <button onclick="confirmDelete('<?= $table ?>', <?= $row[$primaryKey] ?>)">Delete</button>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>

        <h2>Add New <?= ucfirst($table) ?></h2>
        <form method="POST">
            <input type="hidden" name="action" value="add">
            <input type="hidden" name="table" value="<?= $table ?>">
            <?php
            foreach (getColumns($table) as $col) {
                if (strtolower($col) == 'id' || strtolower($col) == getPrimaryKey($table)) continue;
                echo "<label for='$col'>" . ucfirst($col) . ":</label>";
                echo "<input type='text' name='data[$col]' required><br>";
            }
            ?>
            <button type="submit">Add <?= ucfirst($table) ?></button>
        </form>

        <?php if ($table === 'support_messages'): ?>
            <div class="filter-buttons">
                <button onclick="filterMessages('pending')">Present Messages Not Done</button>
                <button onclick="filterMessages('done')">Present Messages Done</button>
            </div>

            <?php
            $supportQuery = $conn->query("
                SELECT sm.*, u.Name AS user_name, a.Username AS admin_name
                FROM support_messages sm
                LEFT JOIN users u ON sm.user_id = u.UserID
                LEFT JOIN admin a ON sm.admin_id = a.AdminID
                ORDER BY sm.submitted_at DESC
            ");
            ?>

            <?php if ($supportQuery): ?>
                <div style="display: flex; flex-wrap: wrap; gap: 20px;">
                    <?php while ($msg = $supportQuery->fetch_assoc()): ?>
                        <div class="support-card" data-responded="<?= $msg['response'] ? '1' : '0' ?>" style="flex: 1 1 300px; border-radius: 10px; padding: 20px; background: <?= $msg['response'] ? '#e6ffee' : '#ffe6e6' ?>; box-shadow: 0 0 10px rgba(0,0,0,0.1);">
                            <h3 style="margin-top:0;">From: <?= htmlspecialchars($msg['user_name'] ?? 'Unknown') ?></h3>
                            <p><strong>Message:</strong><br><?= nl2br(htmlspecialchars($msg['message'])) ?></p>
                            <p><small>Sent at: <?= $msg['submitted_at'] ?></small></p>

                            <?php if ($msg['response']): ?>
                                <div style="margin-top:10px; padding:10px; background:#d4ffd4; border-radius:8px;">
                                    <strong>Admin Response:</strong><br><?= nl2br(htmlspecialchars($msg['response'])) ?><br>
                                    <small>Responded at: <?= $msg['responded_at'] ?></small><br>
                                    <small>By: <?= htmlspecialchars($msg['admin_name'] ?? 'Unknown') ?></small>
                                </div>
                            <?php else: ?>
                                <form method="POST" style="margin-top:15px;">
                                    <input type="hidden" name="support_reply_id" value="<?= $msg['id'] ?>">
                                    <input type="hidden" name="table" value="support_messages">
                                    <textarea name="support_response" required style="width:100%;height:100px;border-radius:5px;padding:10px;margin-bottom:10px;" placeholder="Type your response..."></textarea><br>
                                    <button type="submit" style="background:#27ae60;color:white;padding:10px 20px;border:none;border-radius:5px;cursor:pointer;">Send Response</button>
                                </form>
                            <?php endif; ?>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php else: ?>
                <p style="color: red;">Error loading support messages: <?= $conn->error ?></p>
            <?php endif; ?>
        <?php endif; ?>
    </div>

<script>
    function openEditForm(table, id) {
        window.location.href = 'php/edit.php?table=' + table + '&id=' + id;
    }

    function confirmDelete(table, id) {
        if (confirm("Are you sure you want to delete this record?")) {
            window.location.href = 'php/delete.php?table=' + table + '&id=' + id;
        }
    }

    function showSupportNotice() {
        alert("You have <?= $pendingSupportCount ?> support messages pending!");
    }

    function filterMessages(status) {
        const cards = document.querySelectorAll('.support-card');
        cards.forEach(card => {
            const responded = card.getAttribute('data-responded');
            if ((status === 'pending' && responded === '0') || (status === 'done' && responded === '1')) {
                card.style.display = 'block';
            } else {
                card.style.display = 'none';
            }
        });
    }
</script>

</body>
</html>

<?php $conn->close(); ?>
