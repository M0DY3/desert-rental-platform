<?php 
session_start();

// Ensure the user is logged in
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: index.php");
    exit();
}

// Correctly include db_config.php
include '../php/db_config.php';  // Adjusted path since edit.php is in the 'php' folder

// Get table and ID from the URL
$table = isset($_GET['table']) ? $_GET['table'] : '';
$id = isset($_GET['id']) ? $_GET['id'] : '';

// Get the primary key for the table
$primaryKey = getPrimaryKey($table);

// Fetch the record based on the ID
$sql = "SELECT * FROM $table WHERE $primaryKey = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$record = $result->fetch_assoc();

// Handle form submission for updating the record
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $updateFields = [];
    $values = [];
    foreach ($_POST['data'] as $key => $value) {
        $updateFields[] = "$key = ?";
        $values[] = $value;
    }
    $updateFields = implode(", ", $updateFields);
    
    $sql = "UPDATE $table SET $updateFields WHERE $primaryKey = ?";
    $stmt = $conn->prepare($sql);
    $values[] = $id; // Append ID for the WHERE clause
    $stmt->bind_param(str_repeat('s', count($values)-1) . 'i', ...$values); // Dynamically bind the parameters
    $stmt->execute();
    
    header("Location: ../manage.php?table=$table");
    exit();
}

// Function to get the primary key of a table dynamically
function getPrimaryKey($table) {
    global $conn;
    $result = $conn->query("DESCRIBE $table");
    while ($row = $result->fetch_assoc()) {
        if ($row['Key'] == 'PRI') {
            return $row['Field']; // Return the primary key column
        }
    }
    return null;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit <?= ucfirst($table) ?></title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #e5e5e5;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            background-color: #fff;
            padding: 40px 30px;
            border-radius: 10px;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 700px;
            box-sizing: border-box;
        }

        h1 {
            color: #333;
            font-size: 28px;
            text-align: center;
            margin-bottom: 20px;
            font-weight: 600;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        label {
            font-size: 16px;
            color: #444;
            font-weight: 600;
            margin-bottom: 5px;
        }

        input[type="text"], input[type="email"] {
            padding: 12px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 6px;
            outline: none;
            transition: all 0.3s ease;
            background-color: #fafafa;
        }

        input[type="text"]:focus, input[type="email"]:focus {
            border-color: #4CAF50;
            background-color: #fff;
            box-shadow: 0 0 5px rgba(76, 175, 80, 0.5);
        }

        button {
            padding: 12px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            font-size: 16px;
            border-radius: 6px;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.2s ease;
        }

        button:hover {
            background-color: #45a049;
            transform: scale(1.05);
        }

        button:active {
            transform: scale(1);
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .container {
                padding: 30px 20px;
            }

            h1 {
                font-size: 24px;
            }

            button {
                font-size: 14px;
                padding: 10px 16px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Edit <?= ucfirst($table) ?> Record</h1>
        <form method="POST">
            <?php
            // Dynamically generate the form fields based on the table columns
            $columns = $conn->query("DESCRIBE $table");
            while ($column = $columns->fetch_assoc()) {
                if ($column['Field'] != $primaryKey) {
                    echo "<div class='form-group'>";
                    echo "<label for='{$column['Field']}'>" . ucfirst($column['Field']) . ":</label>";
                    echo "<input type='text' name='data[{$column['Field']}]' value='" . htmlspecialchars($record[$column['Field']]) . "' required><br>";
                    echo "</div>";
                }
            }
            ?>
            <button type="submit">Update</button>
        </form>
    </div>
</body>
</html>

<?php $conn->close(); ?>
