<?php
session_start();

// Ensure the user is logged in
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: index.php");
    exit();
}

include 'php/db_config.php';

// Handle operations (CRUD)
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Add new record
    if ($_POST['action'] == 'add') {
        $table = $_POST['table'];
        $columns = implode(",", array_keys($_POST['data']));
        $values = implode(",", array_map(function($value) use ($conn) {
            return "'" . $conn->real_escape_string($value) . "'";
        }, $_POST['data']));
        $sql = "INSERT INTO $table ($columns) VALUES ($values)";
        $conn->query($sql);
    }

    // Edit record
    if ($_POST['action'] == 'edit') {
        $table = $_POST['table'];
        $id = $_POST['id'];
        $updates = [];
        foreach ($_POST['data'] as $key => $value) {
            $updates[] = "$key = '" . $conn->real_escape_string($value) . "'";
        }
        $updates = implode(",", $updates);
        $sql = "UPDATE $table SET $updates WHERE AdminID = $id"; // Use AdminID for the admin table
        $conn->query($sql);
    }

    // Delete record
    if ($_POST['action'] == 'delete') {
        $table = $_POST['table'];
        $id = $_POST['id'];
        $sql = "DELETE FROM $table WHERE AdminID = $id"; // Use AdminID for the admin table
        $conn->query($sql);
    }
}

// Get table names for navigation
$tableResult = $conn->query("SHOW TABLES");
$tables = [];
while ($row = $tableResult->fetch_row()) {
    $tables[] = $row[0];
}

// Display selected table data
$table = isset($_GET['table']) ? $_GET['table'] : $tables[0];
$tableData = $conn->query("SELECT * FROM $table");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Tables</title>
    <link rel="stylesheet" href="css/manage.css">
</head>
<body>
    <div class="sidebar">
        <h2>Admin Dashboard</h2>
        <?php foreach ($tables as $t): ?>
            <a href="?table=<?= $t ?>"><?= ucfirst($t) ?></a>
        <?php endforeach; ?>
    </div>

    <div class="main-content">
        <h1>Manage <?= ucfirst($table) ?></h1>

        <!-- Table Data -->
        <table>
            <thead>
                <tr>
                    <th>AdminID</th><th>Username</th><th>Email</th><th>Password</th><th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $tableData->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['AdminID']) ?></td>
                        <td><?= htmlspecialchars($row['Username']) ?></td>
                        <td><?= htmlspecialchars($row['Email']) ?></td>
                        <td><?= htmlspecialchars($row['Password']) ?></td>
                        <td>
                            <!-- Edit and Delete buttons with correct AdminID passed to JS -->
                            <button onclick="openEditForm(<?= $row['AdminID'] ?>)">Edit</button>
                            <button onclick="confirmDelete(<?= $row['AdminID'] ?>)">Delete</button>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>

        <!-- Add New Record -->
        <h2>Add New Admin</h2>
        <form method="POST">
            <input type="hidden" name="action" value="add">
            <input type="hidden" name="table" value="admin">
            <label for='AdminID'>AdminID:</label><input type='text' name='data[AdminID]' required><br>
            <label for='Username'>Username:</label><input type='text' name='data[Username]' required><br>
            <label for='Email'>Email:</label><input type='text' name='data[Email]' required><br>
            <label for='Password'>Password:</label><input type='text' name='data[Password]' required><br>
            <button type="submit">Add Admin</button>
        </form>
    </div>

    <script>
        // JavaScript for handling Edit and Delete buttons
        function openEditForm(id) {
            // For now, just alert the id to confirm the functionality
            alert("Edit form for AdminID: " + id);
            // You can now open an edit modal or redirect to an edit page based on the ID
            // Example: window.location.href = 'edit_admin.php?AdminID=' + id;
        }

        function confirmDelete(id) {
            if (confirm("Are you sure you want to delete this record?")) {
                // Perform the delete action, e.g., by redirecting to a PHP script
                // Example: window.location.href = 'delete_admin.php?AdminID=' + id;
                alert("Record with AdminID " + id + " will be deleted.");
                // You can replace the above line with an actual PHP request to delete the record.
            }
        }
    </script>
</body>
</html>

<?php $conn->close(); ?>
