<?php
session_start();
include 'php/db_config.php'; // Ensure this path is correct

// Redirect if already logged in as admin
if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true && isset($_SESSION['admin_id'])) {
    header("Location: admin.php");
    exit();
}

$error = ""; // Variable for login error message

// Handle login for admin
if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['pass'];

    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format.";
    } else {
        $sql = "SELECT * FROM admin WHERE Email = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $admin = $result->fetch_assoc();
            if ($password == $admin['Password']) {
                $_SESSION['logged_in'] = true;
                $_SESSION['user'] = $admin['Email'];
                $_SESSION['admin_id'] = $admin['AdminID'];
                header("Location: manage.php");
                exit();
            } else {
                $error = "Invalid password.";
            }
        } else {
            $error = "Email does not exist.";
        }
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="images/logo.png" type="image/icon type">
    <link rel="stylesheet" href="css/login.css">
    <title>Admin Login - Camping Adventures</title>
</head>
<body>
    <header class="header">
        <a href="#" class="logo">
            <img src="images/logo.png" alt="Camping Logo">
        </a>
        <nav class="nav-items">
            <a href="index.php">Home</a>
            <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true): ?>
                <a href="admin.php">Dashboard</a>
                <a href="logout.php">Logout</a>
            <?php else: ?>
                <a href="admin_login.php">Login</a>
            <?php endif; ?>
        </nav>
    </header>

    <div class="wrapper">
        <div class="title-text">
            <div class="title login">Admin Login</div>
        </div>
        <div class="form-container">
            <form action="" method="POST" class="login">
                <!-- Display error message -->
                <?php if (!empty($error)) echo "<p style='color:red;'>$error</p>"; ?>
                <div class="field">
                    <input type="text" placeholder="Email Address" name="email" required>
                </div>
                <div class="field">
                    <input type="password" placeholder="Password" name="pass" required>
                </div>
                <div class="field btn">
                    <input type="submit" name="login" value="Login">
                </div>
            </form>
        </div>
    </div>
</body>
</html>
